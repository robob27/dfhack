.. comment
    This is the changelog for stable releases. Entries are included from
    changelog.txt.

.. _changelog:

#########
Changelog
#########

This file contains changes grouped by the stable release in which they first
appeared. See `build-changelog` for more information.

See `dev-changelog` for a list of changes grouped by development releases.

.. contents:: Contents
  :local:
  :depth: 1

.. include:: /docs/changelogs/news.rst


Older Changelogs
================
Are kept in a separate file:  `History`

.. that's ``docs/about/History.rst``, if you're reading the raw text.
